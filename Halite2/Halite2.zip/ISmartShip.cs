﻿using Halite2.hlt;

namespace Halite2
{
    public interface ISmartShip
    {
        Move DoWork();
    }
}